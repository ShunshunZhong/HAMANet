import torch
from torch import nn
import torch
import torchvision
from torch import nn
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.utils import save_image
import torch.nn.functional as F
import os
import matplotlib.pyplot as plt
from utils import *
__all__ = ['HAMANet']

import timm
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
import types
import math
from abc import ABCMeta, abstractmethod
from mmcv.cnn import ConvModule
import pdb

##########################################################
class PiAM_Module(nn.Module):
    """ Pixel interaction attention module"""

    # Ref from SAGAN
    def __init__(self, in_dim):
        super(PiAM_Module, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 4, kernel_size=1) #8
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 4, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim // 2, kernel_size=1)
        self.value_conven = nn.Conv2d(in_channels=in_dim // 2, out_channels=in_dim , kernel_size=1)
        #self.value_conv2 = nn.Conv2d(in_channels=in_dim // 2, out_channels=in_dim, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        """
        Parameters:
        ----------
            inputs :
                 x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X (HxW) X (HxW)
        """
        m_batchsize, C, height, width = x.size()
        proj_query = self.query_conv(x).view(m_batchsize, -1, width * height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(m_batchsize, -1, width * height)

        energy = torch.bmm(proj_query, proj_key)
        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(m_batchsize, -1, width * height)

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        C = int(C*0.5)
        out = out.view(m_batchsize, C, height, width)
        out = self.value_conven(out)
        out = self.gamma * out + x
        return out

class SiAM_Module(nn.Module):
    """ Spatial-interaction attention module"""

    def __init__(self, in_dim):
        super(SiAM_Module, self).__init__()
        self.chanel_in = in_dim
        self.proj_valueen = nn.Sequential(
            nn.Conv2d(in_dim, in_dim // 4, 3, 1, 1),
            nn.BatchNorm2d(in_dim // 4),
            nn.ReLU(True),

            nn.Conv2d(in_dim // 4, in_dim, kernel_size=1),
            nn.BatchNorm2d(in_dim),
            nn.Sigmoid(),
        )

        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        """
        Parameters:
        ----------
            inputs :
                 x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X C X C
        """
        m_batchsize, C, height, width = x.size()
        proj_query = x.view(m_batchsize, C, -1) #8,64,
        proj_key = x.view(m_batchsize, C, -1).permute(0, 2, 1)

        energy = torch.bmm(proj_query, proj_key)
        energy_new = torch.max(energy, -1, keepdim=True)[0].expand_as(energy) - energy
        attention = self.softmax(energy_new)
        proj_value = self.proj_valueen(x)
        proj_value = proj_value.view(m_batchsize, C, -1)
        out = torch.bmm(attention, proj_value)
        out = out.view(m_batchsize, C, height, width)

        out = self.gamma * out + x
        return out


class PiAM_SiAM_Layer(nn.Module):
    """
    Helper Function for PiAM and SiAM attention

    Parameters:
    ----------
    input:
        in_ch : input channels
        use_pam : Boolean value whether to use PiAM_Module or SiAM_Module
    output:
        returns the attention map
    """

    def __init__(self, in_ch, use_pam=True):
        super(PiAM_SiAM_Layer, self).__init__()

        self.attn = nn.Sequential(
            nn.Conv2d(in_ch * 2, in_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_ch),
            nn.PReLU(),
            PiAM_Module(in_ch) if use_pam else SiAM_Module(in_ch),
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_ch),
            nn.PReLU()
        )

    def forward(self, x):
        return self.attn(x)

##########################################################

def conv1x1(in_planes: int, out_planes: int, stride: int = 1) -> nn.Conv2d:
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=1, bias=False)

class shiftmlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0., shift_size=5,
                  B=1, C=1, W=1, H=1,D=1):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.dim = in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.CAT = CMLP(hidden_features, B, C, H, W, D)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        #self.drop = nn.Dropout(0.1)
        self.drop = nn.Dropout(drop)

        self.shift_size = shift_size
        self.pad = shift_size // 2

        
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W, D):
        B, N, C = x.shape
        xn = x.transpose(1, 2).view(B, C, H, W).contiguous()
        xn = F.pad(xn, (self.pad, self.pad, self.pad, self.pad) , "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad+1))]
        x_cat = torch.cat(x_shift, 1)
        x_cat = torch.narrow(x_cat, 2, self.pad, H)
        x_s = torch.narrow(x_cat, 3, self.pad, W) # 8，160，16,16

        x_s = x_s.reshape(B,C,H*W).contiguous()
        x_shift_r = x_s.transpose(1,2)

        x = self.fc1(x_shift_r)
        #x = F.relu(x)
        x = self.CAT(x, H, W, D)
        x = self.act(x) 
        x = self.drop(x)
        # 8，256，160
        xn = x.transpose(1, 2).view(B, C, H, W).contiguous()
        xn = F.pad(xn, (self.pad, self.pad, self.pad, self.pad) , "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad+1))]
        x_cat = torch.cat(x_shift, 1)
        x_cat = torch.narrow(x_cat, 2, self.pad, H)
        x_s = torch.narrow(x_cat, 3, self.pad, W)
        x_s = x_s.reshape(B,C,H*W).contiguous()
        x_shift_c = x_s.transpose(1,2)
        x = self.fc2(x_shift_c)
        x = self.drop(x)
        return x



class shiftedBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1, B=1, C=1, H=1, W=1,D=1):
        super().__init__()


        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = shiftmlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop,B=B, C=C, H=H, W=W,D=D)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W, D):

        x = x + self.drop_path(self.mlp(self.norm2(x), H, W, D)) #
        return x


class CMLP(nn.Module):
    def __init__(self, dim=768, B=8, C=160, H=16 ,W=16,D=0.5):
        super(CMLP, self).__init__()
        self.ad = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)
        self.fc13 = nn.Conv2d(H* W* D, H* W* D, 1, 1, 0, bias=False, groups=H* W* D)
        self.fc13_bn = nn.BatchNorm2d(B* D)
    def forward(self, x, H, W, D):
        B, N, C = x.shape
        x = x.transpose(1, 2).view(B, C, H, W)
        #############################################
        fc_inputs = x.reshape(-1, H* W* D, 1, 1)
        x = self.fc13(fc_inputs)
        x = x.reshape(-1, B* D, H, W)
        x = self.fc13_bn(x)
        #x = F.relu(x)
        x = x.reshape(B, C, H, W)
        ############################################
        x = self.ad(x)
        x = x.flatten(2).transpose(1, 2)

        return x

class OverlapPatchEmbed(nn.Module): #用到
    """ Image to Patch Embedding
    """

    def __init__(self, img_size=224, patch_size=7, stride=4, in_chans=3, embed_dim=768):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)

        self.img_size = img_size
        self.patch_size = patch_size
        self.H, self.W = img_size[0] // patch_size[0], img_size[1] // patch_size[1]
        self.num_patches = self.H * self.W
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride,
                              padding=(patch_size[0] // 2, patch_size[1] // 2)) #size 3, stride 2, padding 1 缩小一半
        self.norm = nn.LayerNorm(embed_dim)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.proj(x) #输入 8,128,32,32 输出8,160,16，16
        _, _, H, W = x.shape
        x = x.flatten(2).transpose(1, 2) #先flatten从第二个维度开始压缩，再交换1,2维度
        x = self.norm(x)

        return x, H, W
class ContextualFusionModule(nn.Module):
    def __init__(self, planes_high, planes_low, planes_out, planes_att):
        super(ContextualFusionModule, self).__init__()
        self.down = nn.Sequential(
            nn.Conv2d(planes_low, planes_low//4, kernel_size=1),
            nn.BatchNorm2d(planes_low//4),
            nn.ReLU(True),

            nn.Conv2d(planes_low//4, planes_low, kernel_size=1),
            nn.BatchNorm2d(planes_low),
            nn.Sigmoid(),
        )
        self.plus_conv = nn.Sequential(
            nn.Conv2d(planes_high, planes_low//2, kernel_size=1),
            nn.BatchNorm2d(planes_low//2),
            nn.ReLU(True)
        )
        self.up = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(planes_low//2, planes_low//4, kernel_size=1),
            nn.BatchNorm2d(planes_low//4),
            nn.ReLU(True),

            nn.Conv2d(planes_low//4, planes_low, kernel_size=1),
            nn.BatchNorm2d(planes_low),
            nn.Sigmoid(),
        )
        self.end_conv = nn.Sequential(
            nn.Conv2d(planes_low//2, planes_low, kernel_size=1),
            nn.BatchNorm2d(planes_low),
            nn.ReLU(True),
        )
        self.plus_conv1 = nn.Sequential(
            nn.Conv2d(planes_low, planes_low // 2, 3, 1, 1),
            nn.BatchNorm2d(planes_low // 2),
            nn.ReLU(True)
        )
        self.attloc = nn.Sequential(
            nn.Conv2d(planes_att, planes_att//2, 3, 1, 1),
            nn.BatchNorm2d(planes_att//2),
            nn.Sigmoid(),

            nn.Conv2d(planes_att//2, planes_low, kernel_size=1),
            nn.BatchNorm2d(planes_low),
            nn.ReLU(True),

        )


    def forward(self, x_up, x_attention, x_down):  #t3, up4, pacm3
        x_up = self.plus_conv(x_up)
        down = self.down(x_down)
        up = self.up(x_up)
        x_down = self.plus_conv1(x_down)
        feat = x_down + x_up
        feat = self.end_conv(feat)
        feat = feat * up
        feat = feat * down
        x_attention = F.relu(F.interpolate(x_attention, scale_factor=(2, 2), mode='bilinear'))
        attloc = self.attloc(x_attention)
        feat = feat * attloc

        return feat


class HAMANet(nn.Module):

    ## 2 CG-MLP + 2 CFM+ 3 ATTENTION
    
    def __init__(self,  num_classes, input_channels=3, deep_supervision=False,img_size=224, patch_size=16, in_chans=3,  embed_dims=[ 128, 160, 256],
                 num_heads=[1, 2, 4, 8], mlp_ratios=[4, 4, 4, 4], qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
                 depths=[1, 1, 1], sr_ratios=[8, 4, 2, 1], **kwargs):
        super().__init__()
        
        self.encoder1 = nn.Conv2d(3, 16, 3, stride=1, padding=1)
        self.encoder2 = nn.Conv2d(16, 32, 3, stride=1, padding=1)
        self.encoder3 = nn.Conv2d(32, 128, 3, stride=1, padding=1)

        self.ebn1 = nn.BatchNorm2d(16)
        self.ebn2 = nn.BatchNorm2d(32)
        self.ebn3 = nn.BatchNorm2d(128)
        
        self.norm3 = norm_layer(embed_dims[1])
        self.norm4 = norm_layer(embed_dims[2])

        self.dnorm3 = norm_layer(160)
        self.dnorm4 = norm_layer(128)
        ######################################
        self.pam_attention1 = PiAM_SiAM_Layer(8)
        self.pam_attention2 = PiAM_SiAM_Layer(16)
        self.pam_attention3 = PiAM_SiAM_Layer(64)
        self.cam_attention1 = PiAM_SiAM_Layer(8, False)
        self.cam_attention2 = PiAM_SiAM_Layer(16, False)
        self.cam_attention3 = PiAM_SiAM_Layer(64, False)
        self.att = nn.Conv2d(8, 16, 3, stride=1, padding=1)
        #self.att2 = nn.Conv2d(16, 32, 1, stride=1, padding=0)
        #self.att3 = nn.Conv2d(64, 128, 1, stride=1, padding=0)
        ######################################
        #self.cfuse34 = ContextualFusionModule(128, 128, 128, 160)
        self.cfuse23 = ContextualFusionModule(32, 32, 32, 128)
        self.cfuse12 = ContextualFusionModule(16, 16, 16, 32)

        ##########################################
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]

        self.block1 = nn.ModuleList([shiftedBlock(
            dim=embed_dims[1], num_heads=num_heads[0], mlp_ratio=1, qkv_bias=qkv_bias, qk_scale=qk_scale,
            drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[0], norm_layer=norm_layer,
            sr_ratio=sr_ratios[0],B=16 ,C=160 ,H=16 ,W=16, D=8)])  #dim 160

        self.block2 = nn.ModuleList([shiftedBlock(
            dim=embed_dims[2], num_heads=num_heads[0], mlp_ratio=1, qkv_bias=qkv_bias, qk_scale=qk_scale,
            drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[1], norm_layer=norm_layer,
            sr_ratio=sr_ratios[0],B=16 ,C=256 ,H=8 ,W=8, D=16)]) #dim 256

        self.dblock1 = nn.ModuleList([shiftedBlock(
            dim=embed_dims[1], num_heads=num_heads[0], mlp_ratio=1, qkv_bias=qkv_bias, qk_scale=qk_scale,
            drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[0], norm_layer=norm_layer,
            sr_ratio=sr_ratios[0],B=16 ,C=160 ,H=16 ,W=16, D=8)]) #dim 160

        self.dblock2 = nn.ModuleList([shiftedBlock(
            dim=embed_dims[0], num_heads=num_heads[0], mlp_ratio=1, qkv_bias=qkv_bias, qk_scale=qk_scale,
            drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[1], norm_layer=norm_layer,
            sr_ratio=sr_ratios[0],B=16 ,C=128 ,H=32 ,W=32, D=4)]) #dim 128

        self.patch_embed3 = OverlapPatchEmbed(img_size=img_size // 4, patch_size=3, stride=2, in_chans=embed_dims[0],
                                              embed_dim=embed_dims[1]) #img_size 256,embed_dims[0]=128,1=160,2=156.
        self.patch_embed4 = OverlapPatchEmbed(img_size=img_size // 8, patch_size=3, stride=2, in_chans=embed_dims[1],
                                              embed_dim=embed_dims[2])

        self.decoder1 = nn.Conv2d(256, 160, 3, stride=1,padding=1)  
        self.decoder2 =   nn.Conv2d(160, 128, 3, stride=1, padding=1)  
        self.decoder3 =   nn.Conv2d(128, 32, 3, stride=1, padding=1) 
        self.decoder4 =   nn.Conv2d(32, 16, 3, stride=1, padding=1)
        self.decoder5 =   nn.Conv2d(16, 16, 3, stride=1, padding=1)

        self.dbn1 = nn.BatchNorm2d(160)
        self.dbn2 = nn.BatchNorm2d(128)
        self.dbn3 = nn.BatchNorm2d(32)
        self.dbn4 = nn.BatchNorm2d(16)
        
        self.final = nn.Conv2d(16, num_classes, kernel_size=1)

        self.soft = nn.Softmax(dim =1)

    def forward(self, x):
        
        B = x.shape[0]
        D1 = 8
        D2 = 16
        D3 = 8
        D4 = 4
        ### Conv Stage
        out = F.relu(F.max_pool2d(self.ebn1(self.encoder1(x)),2,2))
        cam1 = self.cam_attention1(out)
        pacm1 = self.att(cam1)
        t1 = out

        out = F.relu(F.max_pool2d(self.ebn2(self.encoder2(out)),2,2))
        pos2 = self.pam_attention2(out)
        cam2 = self.cam_attention2(out)
        pacm2 = torch.cat((pos2, cam2),1)
        t2 = out


        out = F.relu(F.max_pool2d(self.ebn3(self.encoder3(out)),2,2))
        pos3 = self.pam_attention3(out)
        cam3 = self.cam_attention3(out)
        pacm3 = torch.cat((pos3, cam3),1)
        #pacm3= self.att3(pos3)
        t3 = out

        ###########################
        out,H,W = self.patch_embed3(out)

        for i, blk in enumerate(self.block1):
            out = blk(out, H, W, D=D1)

        out = self.norm3(out)
        out = out.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        t4 = out


        ####################################

        out ,H,W= self.patch_embed4(out)
        for i, blk in enumerate(self.block2):
            out = blk(out, H, W, D=D2)
        out = self.norm4(out)
        out = out.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()

        ###########################################################

        out = F.relu(F.interpolate(self.dbn1(self.decoder1(out)),scale_factor=(2,2),mode ='bilinear'))

        out = torch.add(out,t4)
        _,_,H,W = out.shape
        out = out.flatten(2).transpose(1,2)
        for i, blk in enumerate(self.dblock1):
            out = blk(out, H, W, D=D3)

        out = self.dnorm3(out)

        out = out.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        up4=out

        ############################################################

        out = F.relu(F.interpolate(self.dbn2(self.decoder2(out)),scale_factor=(2,2),mode ='bilinear')) #上卷积1 160-128

        out = torch.add(out,t3)
        _,_,H,W = out.shape
        out = out.flatten(2).transpose(1,2)
        
        for i, blk in enumerate(self.dblock2):
            out = blk(out, H, W, D=D4)

        out = self.dnorm4(out)
        out = out.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        ############################################################
        out = torch.add(out, pacm3)
        up3 = out
        out = F.relu(F.interpolate(self.dbn3(self.decoder3(out)),scale_factor=(2,2),mode ='bilinear'))

        cfm2 = self.cfuse23(t2, up3, pacm2)
        out = torch.add(out, cfm2)
        out = torch.add(out, t2) #
        out = torch.add(out, pacm2)
        up2 = out
        out = F.relu(F.interpolate(self.dbn4(self.decoder4(out)),scale_factor=(2,2),mode ='bilinear'))
        cfm1 = self.cfuse12(t1, up2, pacm1)
        out = torch.add(out, cfm1)
        out = torch.add(out,t1)
        out = torch.add(out, pacm1)
        ############################################################
        out = F.relu(F.interpolate(self.decoder5(out),scale_factor=(2,2),mode ='bilinear'))
        #out 8,16,256,256
        return self.final(out)


